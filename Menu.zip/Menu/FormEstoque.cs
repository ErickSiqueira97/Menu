﻿using DocumentFormat.OpenXml.Spreadsheet;
using ClosedXML;
using FirebirdSql.Data.FirebirdClient;
using OfficeOpenXml;
using System;
using System.Security.Cryptography;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Menu
{

    public partial class FormEstoque : Form
    {
        private string connectionString;
        private string caminhoBancoDados = "C:\\SGBR\\Master\\BD\\BASESGMASTER.FDB";

        public FormEstoque()
        {
            InitializeComponent();
            connectionString = $"DataSource=localhost;Database={caminhoBancoDados};Port=3050;User=SYSDBA;Password=masterkey;Charset=UTF8;Dialect=3;Connection lifetime=15;PacketSize=8192;ServerType=0;Unicode=True;Max Pool Size=1000";
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadAllTables();
        }

        private void LoadAllTables()
        {
            using (FbConnection connection = new FbConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "SELECT * FROM TESTOQUE";
                    FbCommand command = new FbCommand(query, connection);
                    FbDataAdapter adapter = new FbDataAdapter(command);
                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                    Console.WriteLine("Dados carregados com sucesso.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    Console.WriteLine("Erro: " + ex.Message);
                }
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            LoadAllTables();
        }

        private void btExportar_Click(object sender, EventArgs e)
        {
            ExportDataGridViewToExcel(dataGridView1);
        }

        private void ExportDataGridViewToExcel(DataGridView dgv)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            if (dgv.Rows.Count > 0)
            {
                using (SaveFileDialog sfd = new SaveFileDialog() { Filter = "Excel Workbook|*.xlsx" })
                {
                    if (sfd.ShowDialog() == DialogResult.OK)
                    {
                        try
                        {
                            using (var package = new ExcelPackage())
                            {
                                var worksheet = package.Workbook.Worksheets.Add("Sheet1");
                                for (int i = 0; i < dgv.Columns.Count; i++)
                                {
                                    worksheet.Cells[1, i + 1].Value = dgv.Columns[i].HeaderText;
                                }

                                for (int i = 0; i < dgv.Rows.Count; i++)
                                {
                                    for (int j = 0; j < dgv.Columns.Count; j++)
                                    {
                                        worksheet.Cells[i + 2, j + 1].Value = dgv.Rows[i].Cells[j].Value?.ToString() ?? string.Empty;
                                    }
                                }

                                package.SaveAs(new FileInfo(sfd.FileName));
                            }

                            MessageBox.Show("Dados exportados com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Erro ao exportar dados: " + ex.Message);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Não há dados para exportar.", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btImportar_Click(object sender, EventArgs e)
        {
            ImportDataGridViewFromExcel(dataGridView1);
        }

        private void ImportDataGridViewFromExcel(DataGridView dgv)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "Excel Workbook|*.xlsx" })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        using (var package = new ExcelPackage(new FileInfo(ofd.FileName)))
                        {
                            var worksheet = package.Workbook.Worksheets[0];
                            DataTable dt = new DataTable();

                            bool firstRow = true;
                            foreach (var cell in worksheet.Cells[1, 1, 1, worksheet.Dimension.End.Column])
                            {
                                dt.Columns.Add(cell.Text);
                            }

                            for (int row = 2; row <= worksheet.Dimension.End.Row; row++)
                            {
                                DataRow dr = dt.NewRow();
                                for (int col = 1; col <= worksheet.Dimension.End.Column; col++)
                                {
                                    dr[col - 1] = worksheet.Cells[row, col].Text;
                                }
                                dt.Rows.Add(dr);
                            }

                            dgv.DataSource = dt;

                            // Atualizar a coluna "controle"
                            UpdateControleColumn(dt, "controle");

                            SaveDataTableToDatabase(dt, "TESTOQUE");
                        }

                        MessageBox.Show("Dados importados com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Erro ao importar dados: " + ex.Message);
                    }
                }
            }
        }

        private void UpdateControleColumn(DataTable dataTable, string controleColumnName)
        {
            using (FbConnection connection = new FbConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = $"SELECT MAX({controleColumnName}) FROM TESTOQUE";
                    FbCommand command = new FbCommand(query, connection);
                    object result = command.ExecuteScalar();

                    int maxControle = result != DBNull.Value ? Convert.ToInt32(result) : 0;

                    foreach (DataRow row in dataTable.Rows)
                    {
                        maxControle++;
                        row[controleColumnName] = maxControle;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao atualizar a coluna 'controle': " + ex.Message);
                }
            }
        }


        private void SaveDataTableToDatabase(DataTable dataTable, string tableName)

        {
            

            using (FbConnection connection = new FbConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Iterar sobre as linhas do DataTable para inserir no banco de dados
                    foreach (DataRow row in dataTable.Rows)
                    {


                        // Montar o comando INSERT
                        string insertQuery = $"INSERT INTO {tableName} (CONTROLE, PRODUTO, TIPOBARRA, CODBARRAS, UNIDADE, \r\n                        PRECOCUSTO, PERCLUCRO, PRECOVENDA, CODGRUPO, GRUPO, \r\n                        OBS, CODFORNECEDOR, FORNECEDOR, TAMANHO, PESO, \r\n                        CUSTOULTIMACOMPRA, CUSTOMEDIO, QTDETOTALCOMPRADA, QTDETOTALVENDIDA, \r\n                        DATAULTIMACOMPRA, DATAULTIMAVENDA, DATAHORACADASTRO, QTDEMINIMA, \r\n                        QTDEMAXIMA, QTDE, ATIVO, NCM, PERCREDITOCICMS, \r\n                        USAGRADE, USASERIAL, ORIGEM, CODTRIBUTACAOIPI, TRIBUTACAOIPI, \r\n                        CODTRIBUTACAOPIS, CODTRIBUTACAOCOFINS, TRIBUTACAOPIS, TRIBUTACAOCOFINS, \r\n                        TIPOTRIBUTACAO, PERCICMSSTINTERNA, PERCMVAORIGINAL, POSSUIICMSST, \r\n                        ISENTO, PERCICMSPROPRIOST, IAT, IPPT, TRIBUTADO, \r\n                        CSOSN, DESCRICAOCSOSN, PESADO, BASECALCULOICMSSTRETIDO, VALORICMSSTRETIDO, \r\n                        ALIQUOTAICMSECF, FOTO, MD5, MENSAGEMNFE, CODMENSAGEMNFE, \r\n                        CODUNIDADEMEDIDA, CODAPLICACAOPRODUTO, APLICACAOPRODUTO, MD5E2, QTDEINICIAL, \r\n                        ALIQUOTAISS, CODIMPOSTOMEDIO, PERCIMPOSTOMEDIO, CODCSTORIGEM, CODIGOCSTORIGEM, \r\n                        CODEMITENTE, DIASVALIDADEPRODUTO, FATORCONVERSAO, TRIBUTACAOSERVICO, \r\n                        REDUCAOBASECALCULOSERVICO, STATUS, DESCRICAOCOMPLEMENTAR, REFERENCIA, \r\n                        PRECOVENDAUSS, PERCMAXIMODESCONTO, VALORCOMISSAOFIXO, PERCCOMISSAO, PRECOMINIMOUSS, \r\n                        PRECOMINIMO, CODCOMPRA, VALORCONVERSAO, VALORFRETE, \r\n                        VALOROUTROS, VALORICMSST, VALORIPI, VALORUNITARIOCOMPRA, PERCPIS, \r\n                        PERCCOFINS, CAMPO1, CAMPO2, CAMPO3, CAMPO4, \r\n                        CAMPO5, CAMPO6, CAMPO7, CAMPO8, CAMPO9, \r\n                        CAMPO10, MARCA, PERCREDUCAOBC, PERCREDUCAOBCST, CODSUBGRUPO, \r\n                        SUBGRUPO, CONTROLARVALIDADE, CODMARCA, PRECOREVENDA, PERCIPI, \r\n                        CFOP, UNIDADECONVERSAOVENDA, VALORCONVERSAOVENDA, CODTABELAPRECO, NOMETABELAPRECO, \r\n                        PERCIMPOSTOMEDIOESTADUAL, PERCIMPOSTOMEDIOMUNICIPAL, CODIGOENQUADRAMENTOIPI, CEST, QTDEEMPRODUCAO, \r\n                        QTDEPEDIDOVENDA, QTDEPEDIDOCOMPRA, QTDERESERVADA, QTDEREAL, \r\n                        QTDEEMPRODUCAOMP, UNIDADEMEDIDAETIQUETA, FATORCONVERSAOETIQUETA, CODIGOANP, DESCRICAOANP, \r\n                        PERCGLPCOMB, PERCGNNCOMB, PERCGNICOMB, VALORPARTIDACOMB, CNPJFABRICANTE, \r\n                        CODBENEFICIOFISCAL, CODIGOANVISA, SELOIPI, ALIQUOTAFCP, \r\n                        PERCFCPST, CODUNIDADETRIBUTAVEL, UNIDADETRIBUTAVEL, QTDETRIBUTAVEL, DESMONTARNAVENDA, \r\n                        ALIQUOTAICMSSTRET, VALORBCICMSSTRET, VALORICMSSTRET, ALIQUOTAICMSEFET, PERCREDUCAOICMSEFET, \r\n                        VALORBCICMSEFET, VALORICMSEFET, VALORICMSSUBSTITUTO, CODBARRASCAIXA, ENVIARDADOS, \r\n                        VALORPMC, MD5O, MD5S, VALORFCPST, LOCALIZACAO, \r\n                        VOLUME, MOSTRARCOZINHA, CODBARRASINTERNO, CODBARRASTRIB, VACINA, \r\n                        PERCDESCONTOCAIXA, SINCRONIZADO, PERCCASHBACK, PESOLIQUIDO) " +
                            $"VALUES ( @CONTROLE, @PRODUTO, @TIPOBARRA, @CODBARRAS, @UNIDADE, \r\n                        @PRECOCUSTO, @PERCLUCRO, @PRECOVENDA, @CODGRUPO, @GRUPO, \r\n                        @OBS, @CODFORNECEDOR, @FORNECEDOR, @TAMANHO, @PESO, \r\n                        @CUSTOULTIMACOMPRA, @CUSTOMEDIO, @QTDETOTALCOMPRADA, @QTDETOTALVENDIDA, \r\n                        @DATAULTIMACOMPRA, @DATAULTIMAVENDA, @DATAHORACADASTRO, @QTDEMINIMA, \r\n                        @QTDEMAXIMA, @QTDE, @ATIVO, @NCM, @PERCREDITOCICMS, \r\n                        @USAGRADE, @USASERIAL, @ORIGEM, @CODTRIBUTACAOIPI, @TRIBUTACAOIPI, \r\n                        @CODTRIBUTACAOPIS, @CODTRIBUTACAOCOFINS, @TRIBUTACAOPIS, @TRIBUTACAOCOFINS, \r\n                        @TIPOTRIBUTACAO, @PERCICMSSTINTERNA, @PERCMVAORIGINAL, @POSSUIICMSST, \r\n                        @ISENTO, @PERCICMSPROPRIOST, @IAT, @IPPT, @TRIBUTADO, \r\n                        @CSOSN, @DESCRICAOCSOSN, @PESADO, @BASECALCULOICMSSTRETIDO, @VALORICMSSTRETIDO, \r\n                        @ALIQUOTAICMSECF, @FOTO, @MD5, @MENSAGEMNFE, @CODMENSAGEMNFE, \r\n                        @CODUNIDADEMEDIDA, @CODAPLICACAOPRODUTO, @APLICACAOPRODUTO, @MD5E2, @QTDEINICIAL, \r\n                        @ALIQUOTAISS, @CODIMPOSTOMEDIO, @PERCIMPOSTOMEDIO, @CODCSTORIGEM, @CODIGOCSTORIGEM, \r\n                        @CODEMITENTE, @DIASVALIDADEPRODUTO, @FATORCONVERSAO, @TRIBUTACAOSERVICO, \r\n                        @REDUCAOBASECALCULOSERVICO, @STATUS, @DESCRICAOCOMPLEMENTAR, @REFERENCIA, \r\n                        @PRECOVENDAUSS, @PERCMAXIMODESCONTO, @VALORCOMISSAOFIXO, @PERCCOMISSAO, @PRECOMINIMOUSS, \r\n                        @PRECOMINIMO, @CODCOMPRA, @VALORCONVERSAO, @VALORFRETE, \r\n                        @VALOROUTROS, @VALORICMSST, @VALORIPI, @VALORUNITARIOCOMPRA, @PERCPIS, \r\n                        @PERCCOFINS, @CAMPO1, @CAMPO2, @CAMPO3, @CAMPO4, \r\n                        @CAMPO5, @CAMPO6, @CAMPO7, @CAMPO8, @CAMPO9, \r\n                        @CAMPO10, @MARCA, @PERCREDUCAOBC, @PERCREDUCAOBCST, @CODSUBGRUPO, \r\n                        @SUBGRUPO, @CONTROLARVALIDADE, @CODMARCA, @PRECOREVENDA, @PERCIPI, \r\n                        @CFOP, @UNIDADECONVERSAOVENDA, @VALORCONVERSAOVENDA, @CODTABELAPRECO, @NOMETABELAPRECO, \r\n                        @PERCIMPOSTOMEDIOESTADUAL, @PERCIMPOSTOMEDIOMUNICIPAL, @CODIGOENQUADRAMENTOIPI, @CEST, @QTDEEMPRODUCAO, \r\n                        @QTDEPEDIDOVENDA, @QTDEPEDIDOCOMPRA, @QTDERESERVADA, @QTDEREAL, \r\n                        @QTDEEMPRODUCAOMP, @UNIDADEMEDIDAETIQUETA, @FATORCONVERSAOETIQUETA, @CODIGOANP, @DESCRICAOANP, \r\n                        @PERCGLPCOMB, @PERCGNNCOMB, @PERCGNICOMB, @VALORPARTIDACOMB, @CNPJFABRICANTE, \r\n                        @CODBENEFICIOFISCAL, @CODIGOANVISA, @SELOIPI, @ALIQUOTAFCP, \r\n                        @PERCFCPST, @CODUNIDADETRIBUTAVEL, @UNIDADETRIBUTAVEL, @QTDETRIBUTAVEL, @DESMONTARNAVENDA, \r\n                        @ALIQUOTAICMSSTRET, @VALORBCICMSSTRET, @VALORICMSSTRET, @ALIQUOTAICMSEFET, @PERCREDUCAOICMSEFET, \r\n                        @VALORBCICMSEFET, @VALORICMSEFET, @VALORICMSSUBSTITUTO, @CODBARRASCAIXA, @ENVIARDADOS, \r\n                        @VALORPMC, @MD5O, @MD5S, @VALORFCPST, @LOCALIZACAO, \r\n                        @VOLUME, @MOSTRARCOZINHA, @CODBARRASINTERNO, @CODBARRASTRIB, @VACINA, \r\n                        @PERCDESCONTOCAIXA, @SINCRONIZADO, @PERCCASHBACK, @PESOLIQUIDO)";

                        using (FbCommand command = new FbCommand(insertQuery, connection))
                        {
                            

                            // Definir parâmetros para cada coluna do DataTable
                            command.Parameters.AddWithValue("@CONTROLE", row["CONTROLE"]);
                            command.Parameters.AddWithValue("@PRODUTO", row["PRODUTO"]);
                            command.Parameters.AddWithValue("@TIPOBARRA", row["TIPOBARRA"]);
                            command.Parameters.AddWithValue("@CODBARRAS", row["CODBARRAS"]);
                            command.Parameters.AddWithValue("@UNIDADE", row["UNIDADE"]);
                            command.Parameters.AddWithValue("@PRECOCUSTO", row["PRECOCUSTO"]);
                            command.Parameters.AddWithValue("@PERCLUCRO", row["PERCLUCRO"]);
                            command.Parameters.AddWithValue("@PRECOVENDA", row["PRECOVENDA"]);
                            command.Parameters.AddWithValue("@CODGRUPO", row["CODGRUPO"]);
                            command.Parameters.AddWithValue("@GRUPO", row["GRUPO"]);
                            command.Parameters.AddWithValue("@OBS", row["OBS"]);
                            command.Parameters.AddWithValue("@CODFORNECEDOR", row["CODFORNECEDOR"]);
                            command.Parameters.AddWithValue("@FORNECEDOR", row["FORNECEDOR"]);
                            command.Parameters.AddWithValue("@TAMANHO", row["TAMANHO"]);
                            command.Parameters.AddWithValue("@PESO", row["PESO"]);
                            command.Parameters.AddWithValue("@CUSTOULTIMACOMPRA", row["CUSTOULTIMACOMPRA"]);
                            command.Parameters.AddWithValue("@CUSTOMEDIO", row["CUSTOMEDIO"]);
                            command.Parameters.AddWithValue("@QTDETOTALCOMPRADA", row["QTDETOTALCOMPRADA"]);
                            command.Parameters.AddWithValue("@QTDETOTALVENDIDA", row["QTDETOTALVENDIDA"]);
                            command.Parameters.AddWithValue("@DATAULTIMACOMPRA", row["DATAULTIMACOMPRA"]);
                            command.Parameters.AddWithValue("@DATAULTIMAVENDA", row["DATAULTIMAVENDA"]);
                            command.Parameters.AddWithValue("@DATAHORACADASTRO", row["DATAHORACADASTRO"]);
                            command.Parameters.AddWithValue("@QTDEMINIMA", row["QTDEMINIMA"]);
                            command.Parameters.AddWithValue("@QTDEMAXIMA", row["QTDEMAXIMA"]);
                            command.Parameters.AddWithValue("@QTDE", row["QTDE"]);
                            command.Parameters.AddWithValue("@ATIVO", row["ATIVO"]);
                            command.Parameters.AddWithValue("@NCM", row["NCM"]);
                            command.Parameters.AddWithValue("@PERCREDITOCICMS", row["PERCREDITOCICMS"]);
                            command.Parameters.AddWithValue("@USAGRADE", row["USAGRADE"]);
                            command.Parameters.AddWithValue("@USASERIAL", row["USASERIAL"]);
                            command.Parameters.AddWithValue("@ORIGEM", row["ORIGEM"]);
                            command.Parameters.AddWithValue("@CODTRIBUTACAOIPI", row["CODTRIBUTACAOIPI"]);
                            command.Parameters.AddWithValue("@TRIBUTACAOIPI", row["TRIBUTACAOIPI"]);
                            command.Parameters.AddWithValue("@CODTRIBUTACAOPIS", row["CODTRIBUTACAOPIS"]);
                            command.Parameters.AddWithValue("@CODTRIBUTACAOCOFINS", row["CODTRIBUTACAOCOFINS"]);
                            command.Parameters.AddWithValue("@TRIBUTACAOPIS", row["TRIBUTACAOPIS"]);
                            command.Parameters.AddWithValue("@TRIBUTACAOCOFINS", row["TRIBUTACAOCOFINS"]);
                            command.Parameters.AddWithValue("@TIPOTRIBUTACAO", row["TIPOTRIBUTACAO"]);
                            command.Parameters.AddWithValue("@PERCICMSSTINTERNA", row["PERCICMSSTINTERNA"]);
                            command.Parameters.AddWithValue("@PERCMVAORIGINAL", row["PERCMVAORIGINAL"]);
                            command.Parameters.AddWithValue("@POSSUIICMSST", row["POSSUIICMSST"]);
                            command.Parameters.AddWithValue("@ISENTO", row["ISENTO"]);
                            command.Parameters.AddWithValue("@PERCICMSPROPRIOST", row["PERCICMSPROPRIOST"]);
                            command.Parameters.AddWithValue("@IAT", row["IAT"]);
                            command.Parameters.AddWithValue("@IPPT", row["IPPT"]);
                            command.Parameters.AddWithValue("@TRIBUTADO", row["TRIBUTADO"]);
                            command.Parameters.AddWithValue("@CSOSN", row["CSOSN"]);
                            command.Parameters.AddWithValue("@DESCRICAOCSOSN", row["DESCRICAOCSOSN"]);
                            command.Parameters.AddWithValue("@PESADO", row["PESADO"]);
                            command.Parameters.AddWithValue("@BASECALCULOICMSSTRETIDO", row["BASECALCULOICMSSTRETIDO"]);
                            command.Parameters.AddWithValue("@VALORICMSSTRETIDO", row["VALORICMSSTRETIDO"]);
                            command.Parameters.AddWithValue("@ALIQUOTAICMSECF", row["ALIQUOTAICMSECF"]);
                            command.Parameters.AddWithValue("@FOTO", row["FOTO"]);
                            command.Parameters.AddWithValue("@MD5", row["MD5"]);
                            command.Parameters.AddWithValue("@MENSAGEMNFE", row["MENSAGEMNFE"]);
                            command.Parameters.AddWithValue("@CODMENSAGEMNFE", row["CODMENSAGEMNFE"]);
                            command.Parameters.AddWithValue("@CODUNIDADEMEDIDA", row["CODUNIDADEMEDIDA"]);
                            command.Parameters.AddWithValue("@CODAPLICACAOPRODUTO", row["CODAPLICACAOPRODUTO"]);
                            command.Parameters.AddWithValue("@APLICACAOPRODUTO", row["APLICACAOPRODUTO"]);
                            command.Parameters.AddWithValue("@MD5E2", row["MD5E2"]);
                            command.Parameters.AddWithValue("@QTDEINICIAL", row["QTDEINICIAL"]);
                            command.Parameters.AddWithValue("@ALIQUOTAISS", row["ALIQUOTAISS"]);
                            command.Parameters.AddWithValue("@CODIMPOSTOMEDIO", row["CODIMPOSTOMEDIO"]);
                            command.Parameters.AddWithValue("@PERCIMPOSTOMEDIO", row["PERCIMPOSTOMEDIO"]);
                            command.Parameters.AddWithValue("@CODCSTORIGEM", row["CODCSTORIGEM"]);
                            command.Parameters.AddWithValue("@CODIGOCSTORIGEM", row["CODIGOCSTORIGEM"]);
                            command.Parameters.AddWithValue("@CODEMITENTE", row["CODEMITENTE"]);
                            command.Parameters.AddWithValue("@DIASVALIDADEPRODUTO", row["DIASVALIDADEPRODUTO"]);
                            command.Parameters.AddWithValue("@FATORCONVERSAO", row["FATORCONVERSAO"]);
                            command.Parameters.AddWithValue("@TRIBUTACAOSERVICO", row["TRIBUTACAOSERVICO"]);
                            command.Parameters.AddWithValue("@REDUCAOBASECALCULOSERVICO", row["REDUCAOBASECALCULOSERVICO"]);
                            command.Parameters.AddWithValue("@STATUS", row["STATUS"]);
                            command.Parameters.AddWithValue("@DESCRICAOCOMPLEMENTAR", row["DESCRICAOCOMPLEMENTAR"]);
                            command.Parameters.AddWithValue("@REFERENCIA", row["REFERENCIA"]);
                            command.Parameters.AddWithValue("@PRECOVENDAUSS", row["PRECOVENDAUSS"]);
                            command.Parameters.AddWithValue("@PERCMAXIMODESCONTO", row["PERCMAXIMODESCONTO"]);
                            command.Parameters.AddWithValue("@VALORCOMISSAOFIXO", row["VALORCOMISSAOFIXO"]);
                            command.Parameters.AddWithValue("@PERCCOMISSAO", row["PERCCOMISSAO"]);
                            command.Parameters.AddWithValue("@PRECOMINIMOUSS", row["PRECOMINIMOUSS"]);
                            command.Parameters.AddWithValue("@PRECOMINIMO", row["PRECOMINIMO"]);
                            command.Parameters.AddWithValue("@CODCOMPRA", row["CODCOMPRA"]);
                            command.Parameters.AddWithValue("@VALORCONVERSAO", row["VALORCONVERSAO"]);
                            command.Parameters.AddWithValue("@VALORFRETE", row["VALORFRETE"]);
                            command.Parameters.AddWithValue("@VALOROUTROS", row["VALOROUTROS"]);
                            command.Parameters.AddWithValue("@VALORICMSST", row["VALORICMSST"]);
                            command.Parameters.AddWithValue("@VALORIPI", row["VALORIPI"]);
                            command.Parameters.AddWithValue("@VALORUNITARIOCOMPRA", row["VALORUNITARIOCOMPRA"]);
                            command.Parameters.AddWithValue("@PERCPIS", row["PERCPIS"]);
                            command.Parameters.AddWithValue("@PERCCOFINS", row["PERCCOFINS"]);
                            command.Parameters.AddWithValue("@CAMPO1", row["CAMPO1"]);
                            command.Parameters.AddWithValue("@CAMPO2", row["CAMPO2"]);
                            command.Parameters.AddWithValue("@CAMPO3", row["CAMPO3"]);
                            command.Parameters.AddWithValue("@CAMPO4", row["CAMPO4"]);
                            command.Parameters.AddWithValue("@CAMPO5", row["CAMPO5"]);
                            command.Parameters.AddWithValue("@CAMPO6", row["CAMPO6"]);
                            command.Parameters.AddWithValue("@CAMPO7", row["CAMPO7"]);
                            command.Parameters.AddWithValue("@CAMPO8", row["CAMPO8"]);
                            command.Parameters.AddWithValue("@CAMPO9", row["CAMPO9"]);
                            command.Parameters.AddWithValue("@CAMPO10", row["CAMPO10"]);
                            command.Parameters.AddWithValue("@MARCA", row["MARCA"]);
                            command.Parameters.AddWithValue("@PERCREDUCAOBC", row["PERCREDUCAOBC"]);
                            command.Parameters.AddWithValue("@PERCREDUCAOBCST", row["PERCREDUCAOBCST"]);
                            command.Parameters.AddWithValue("@CODSUBGRUPO", row["CODSUBGRUPO"]);
                            command.Parameters.AddWithValue("@SUBGRUPO", row["SUBGRUPO"]);
                            command.Parameters.AddWithValue("@CONTROLARVALIDADE", row["CONTROLARVALIDADE"]);
                            command.Parameters.AddWithValue("@CODMARCA", row["CODMARCA"]);
                            command.Parameters.AddWithValue("@PRECOREVENDA", row["PRECOREVENDA"]);
                            command.Parameters.AddWithValue("@PERCIPI", row["PERCIPI"]);
                            command.Parameters.AddWithValue("@CFOP", row["CFOP"]);
                            command.Parameters.AddWithValue("@UNIDADECONVERSAOVENDA", row["UNIDADECONVERSAOVENDA"]);
                            command.Parameters.AddWithValue("@VALORCONVERSAOVENDA", row["VALORCONVERSAOVENDA"]);
                            command.Parameters.AddWithValue("@CODTABELAPRECO", row["CODTABELAPRECO"]);
                            command.Parameters.AddWithValue("@NOMETABELAPRECO", row["NOMETABELAPRECO"]);
                            command.Parameters.AddWithValue("@PERCIMPOSTOMEDIOESTADUAL", row["PERCIMPOSTOMEDIOESTADUAL"]);
                            command.Parameters.AddWithValue("@PERCIMPOSTOMEDIOMUNICIPAL", row["PERCIMPOSTOMEDIOMUNICIPAL"]);
                            command.Parameters.AddWithValue("@CODIGOENQUADRAMENTOIPI", row["CODIGOENQUADRAMENTOIPI"]);
                            command.Parameters.AddWithValue("@CEST", row["CEST"]);
                            command.Parameters.AddWithValue("@QTDEEMPRODUCAO", row["QTDEEMPRODUCAO"]);
                            command.Parameters.AddWithValue("@QTDEPEDIDOVENDA", row["QTDEPEDIDOVENDA"]);
                            command.Parameters.AddWithValue("@QTDEPEDIDOCOMPRA", row["QTDEPEDIDOCOMPRA"]);
                            command.Parameters.AddWithValue("@QTDERESERVADA", row["QTDERESERVADA"]);
                            command.Parameters.AddWithValue("@QTDEREAL", row["QTDEREAL"]);
                            command.Parameters.AddWithValue("@QTDEEMPRODUCAOMP", row["QTDEEMPRODUCAOMP"]);
                            command.Parameters.AddWithValue("@UNIDADEMEDIDAETIQUETA", row["UNIDADEMEDIDAETIQUETA"]);
                            command.Parameters.AddWithValue("@FATORCONVERSAOETIQUETA", row["FATORCONVERSAOETIQUETA"]);
                            command.Parameters.AddWithValue("@CODIGOANP", row["CODIGOANP"]);
                            command.Parameters.AddWithValue("@DESCRICAOANP", row["DESCRICAOANP"]);
                            command.Parameters.AddWithValue("@PERCGLPCOMB", row["PERCGLPCOMB"]);
                            command.Parameters.AddWithValue("@PERCGNNCOMB", row["PERCGNNCOMB"]);
                            command.Parameters.AddWithValue("@PERCGNICOMB", row["PERCGNICOMB"]);
                            command.Parameters.AddWithValue("@VALORPARTIDACOMB", row["VALORPARTIDACOMB"]);
                            command.Parameters.AddWithValue("@CNPJFABRICANTE", row["CNPJFABRICANTE"]);
                            command.Parameters.AddWithValue("@CODBENEFICIOFISCAL", row["CODBENEFICIOFISCAL"]);
                            command.Parameters.AddWithValue("@CODIGOANVISA", row["CODIGOANVISA"]);
                            command.Parameters.AddWithValue("@SELOIPI", row["SELOIPI"]);
                            command.Parameters.AddWithValue("@ALIQUOTAFCP", row["ALIQUOTAFCP"]);
                            command.Parameters.AddWithValue("@PERCFCPST", row["PERCFCPST"]);
                            command.Parameters.AddWithValue("@CODUNIDADETRIBUTAVEL", row["CODUNIDADETRIBUTAVEL"]);
                            command.Parameters.AddWithValue("@UNIDADETRIBUTAVEL", row["UNIDADETRIBUTAVEL"]);
                            command.Parameters.AddWithValue("@QTDETRIBUTAVEL", row["QTDETRIBUTAVEL"]);
                            command.Parameters.AddWithValue("@DESMONTARNAVENDA", row["DESMONTARNAVENDA"]);
                            command.Parameters.AddWithValue("@ALIQUOTAICMSSTRET", row["ALIQUOTAICMSSTRET"]);
                            command.Parameters.AddWithValue("@VALORBCICMSSTRET", row["VALORBCICMSSTRET"]);
                            command.Parameters.AddWithValue("@VALORICMSSTRET", row["VALORICMSSTRET"]);
                            command.Parameters.AddWithValue("@ALIQUOTAICMSEFET", row["ALIQUOTAICMSEFET"]);
                            command.Parameters.AddWithValue("@PERCREDUCAOICMSEFET", row["PERCREDUCAOICMSEFET"]);
                            command.Parameters.AddWithValue("@VALORBCICMSEFET", row["VALORBCICMSEFET"]);
                            command.Parameters.AddWithValue("@VALORICMSEFET", row["VALORICMSEFET"]);
                            command.Parameters.AddWithValue("@VALORICMSSUBSTITUTO", row["VALORICMSSUBSTITUTO"]);
                            command.Parameters.AddWithValue("@CODBARRASCAIXA", row["CODBARRASCAIXA"]);
                            command.Parameters.AddWithValue("@ENVIARDADOS", row["ENVIARDADOS"]);
                            command.Parameters.AddWithValue("@VALORPMC", row["VALORPMC"]);
                            command.Parameters.AddWithValue("@MD5O", row["MD5O"]);
                            command.Parameters.AddWithValue("@MD5S", row["MD5S"]);
                            command.Parameters.AddWithValue("@VALORFCPST", row["VALORFCPST"]);
                            command.Parameters.AddWithValue("@LOCALIZACAO", row["LOCALIZACAO"]);
                            command.Parameters.AddWithValue("@VOLUME", row["VOLUME"]);
                            command.Parameters.AddWithValue("@MOSTRARCOZINHA", row["MOSTRARCOZINHA"]);
                            command.Parameters.AddWithValue("@CODBARRASINTERNO", row["CODBARRASINTERNO"]);
                            command.Parameters.AddWithValue("@CODBARRASTRIB", row["CODBARRASTRIB"]);
                            command.Parameters.AddWithValue("@VACINA", row["VACINA"]);
                            command.Parameters.AddWithValue("@PERCDESCONTOCAIXA", row["PERCDESCONTOCAIXA"]);
                            command.Parameters.AddWithValue("@SINCRONIZADO", row["SINCRONIZADO"]);
                            command.Parameters.AddWithValue("@PERCCASHBACK", row["PERCCASHBACK"]);
                            command.Parameters.AddWithValue("@PESOLIQUIDO", row["PESOLIQUIDO"]);


                            // Dados que você quer calcular o hash MD5
                            string dadosParaMd5 = "dados_para_md5";

                            // Calcula o hash MD5
                            byte[] md5Bytes = Utilitarios.CalcularHashMD5(dadosParaMd5);

                            // Exemplo de uso do md5Bytes, por exemplo, salvar no banco de dados
                            // ... seu código para salvar os dados, incluindo o hash MD5

                            Console.WriteLine(BitConverter.ToString(md5Bytes).Replace("-", "").ToLower());
                           
                            string md5String = BitConverter.ToString(md5Bytes).Replace("-", "").ToLower();



                            command.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("Dados salvos com sucesso!", "Informação", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                
        
                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao salvar dados: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

       
        private void FormEstoque_Load(object sender, EventArgs e)
        {

        }
    }
}




    