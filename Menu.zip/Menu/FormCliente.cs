﻿using FirebirdSql.Data.FirebirdClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Menu
{
    public partial class FormClientes : Form
    {
        private string connectionString;
        private string caminhoBancoDados = "C:\\SGBR\\Master\\BD\\BASESGMASTER.FDB";

        public FormClientes()
        {
            InitializeComponent();
            connectionString = $"DataSource=localhost;Database={caminhoBancoDados};Port=3050;User=SYSDBA;Password=masterkey;Charset=UTF8;Dialect=3;Connection lifetime=15;PacketSize=8192;ServerType=0;Unicode=True;Max Pool Size=1000";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadAllTables();
        }
        private void LoadAllTables()

        {
            using (FbConnection connection = new FbConnection(connectionString))

            {
                try
                {
                    connection.Open();
                    // Obter todos os nomes de tabelas do banco de dados
                    string getTablesQuery = "SELECT RDB$RELATION_NAME FROM RDB$RELATIONS WHERE RDB$VIEW_BLR IS NULL AND RDB$SYSTEM_FLAG = 0";
                    FbCommand getTablesCommand = new FbCommand(getTablesQuery, connection);
                    FbDataAdapter tablesAdapter = new FbDataAdapter(getTablesCommand);
                    DataTable tablesDataTable = new DataTable();
                    tablesAdapter.Fill(tablesDataTable);

                    DataSet dataSet = new DataSet();
                    foreach (DataRow row in tablesDataTable.Rows)


                    {
                        string tableName = row[0].ToString().Trim();
                        string query = "SELECT * FROM TCLIENTE";
                        FbCommand command = new FbCommand(query, connection);
                        FbDataAdapter adapter = new FbDataAdapter(command);
                        DataTable dataTable = new DataTable(tableName);
                        adapter.Fill(dataTable);
                        dataSet.Tables.Add(dataTable);
                    }
                    // Verificar se há tabelas no DataSet
                    if (dataSet.Tables.Count > 0)
                    {
                        // Exibir dados no DataGridView
                        dataGridView1.DataSource = dataSet.Tables[0]; // Exibir a primeira tabela como exemplo

                        Console.WriteLine("Dados carregados com sucesso.");
                    }

                    else
                    {
                        MessageBox.Show("Nenhuma tabela encontrada no banco de dados.");
                    }
                }

                catch (Exception ex)
                {
                    MessageBox.Show("Erro ao conectar ao banco de dados: " + ex.Message);
                    Console.WriteLine("Erro: " + ex.Message);
                }
            }

            

           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            LoadAllTables();
        }
    }
}

    