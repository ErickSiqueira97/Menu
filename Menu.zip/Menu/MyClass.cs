﻿using System;
using System.Security.Cryptography;
using System.Text;

public class Utilitarios
{
    public static byte[] CalcularHashMD5(string input)
    {
        using (MD5 md5 = MD5.Create())
        {
            byte[] inputBytes = Encoding.UTF8.GetBytes(input);
            return md5.ComputeHash(inputBytes);
        }
    }
}
