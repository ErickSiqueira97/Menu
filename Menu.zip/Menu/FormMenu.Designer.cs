﻿namespace Menu
{
    partial class FormMenu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormMenu));
            this.btEstoque = new System.Windows.Forms.Button();
            this.btFornecedores = new System.Windows.Forms.Button();
            this.BtCliente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btEstoque
            // 
            this.btEstoque.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btEstoque.FlatAppearance.BorderSize = 0;
            this.btEstoque.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btEstoque.Image = global::Menu.Properties.Resources.caixa;
            this.btEstoque.Location = new System.Drawing.Point(12, 12);
            this.btEstoque.Name = "btEstoque";
            this.btEstoque.Size = new System.Drawing.Size(53, 54);
            this.btEstoque.TabIndex = 2;
            this.btEstoque.UseVisualStyleBackColor = true;
            this.btEstoque.Click += new System.EventHandler(this.btEstoque_Click);
            // 
            // btFornecedores
            // 
            this.btFornecedores.FlatAppearance.BorderSize = 0;
            this.btFornecedores.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btFornecedores.Image = global::Menu.Properties.Resources.homem_gravata;
            this.btFornecedores.Location = new System.Drawing.Point(132, 12);
            this.btFornecedores.Name = "btFornecedores";
            this.btFornecedores.Size = new System.Drawing.Size(57, 54);
            this.btFornecedores.TabIndex = 1;
            this.btFornecedores.UseVisualStyleBackColor = true;
            this.btFornecedores.Click += new System.EventHandler(this.btFornecedores_Click);
            // 
            // BtCliente
            // 
            this.BtCliente.FlatAppearance.BorderSize = 0;
            this.BtCliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BtCliente.Image = global::Menu.Properties.Resources.pessoa;
            this.BtCliente.Location = new System.Drawing.Point(71, 12);
            this.BtCliente.Name = "BtCliente";
            this.BtCliente.Size = new System.Drawing.Size(55, 54);
            this.BtCliente.TabIndex = 0;
            this.BtCliente.UseVisualStyleBackColor = true;
            this.BtCliente.Click += new System.EventHandler(this.BtCliente_Click);
            // 
            // FormMenu
            // 
            this.AccessibleRole = System.Windows.Forms.AccessibleRole.None;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(760, 73);
            this.Controls.Add(this.btEstoque);
            this.Controls.Add(this.btFornecedores);
            this.Controls.Add(this.BtCliente);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormMenu";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.RightToLeftLayout = true;
            this.TransparencyKey = System.Drawing.Color.Black;
            this.Load += new System.EventHandler(this.FormMenu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button BtClientes;
        private System.Windows.Forms.Button BtCliente;
        private System.Windows.Forms.Button btFornecedores;
        private System.Windows.Forms.Button btEstoque;
    }
}

