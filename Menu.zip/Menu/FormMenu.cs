﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Menu
{
    public partial class FormMenu : Form

    {

        private FormClientes formClientes = null;
        private FormFornecedores formFornecedores = null;
        private FormEstoque formEstoque = null;
        public FormMenu()
        {
            InitializeComponent();
            this.Resize += FormMenu_Resize;
        }

        private void FormMenu_Load(object sender, EventArgs e)
        {
            // Ajustar a localização e o tamanho do form
            this.Top = 0;
            this.Left = 0;
            this.Width = Screen.PrimaryScreen.Bounds.Width;
            this.Height = 175; // Defina a altura desejada para o FormMenu
        }

        private void FormMenu_Resize(object sender, EventArgs e)
        {
            // Reajusta o tamanho e a posição do FormMenu quando for redimensionado
            this.Top = 0;
            this.Left = 0;
            this.Width = Screen.PrimaryScreen.Bounds.Width;
        }

        private void btFornecedores_Click(object sender, EventArgs e)
        {
            if (formFornecedores == null || formFornecedores.IsDisposed)
            {
                formFornecedores = new FormFornecedores();
                ArrangeFormBelow(formFornecedores);
            }
            else
            {
                formFornecedores.BringToFront();
            }
        }
        private void btEstoque_Click(object sender, EventArgs e)
        {
            if (formEstoque == null || formEstoque.IsDisposed)
            {
                formEstoque = new FormEstoque();
                ArrangeFormBelow(formEstoque);
            }
            else
            {
                formEstoque.BringToFront();
            }
        }

        private void BtCliente_Click(object sender, EventArgs e)
        {
            if (formClientes == null || formClientes.IsDisposed)
            {
                formClientes = new FormClientes();
                ArrangeFormBelow(formClientes);
            }
            else
            {
                formClientes.BringToFront();
            }
        }

        private void ArrangeFormBelow(Form form)
        {
            form.StartPosition = FormStartPosition.Manual;
            form.Location = new Point(this.Left, this.Bottom); // Ajuste a localização para abaixo do FormMenu
            form.Width = this.Width;
            form.Height = Screen.PrimaryScreen.Bounds.Height - this.Height; // Ajuste a altura para ocupar o resto da tela
            form.Show();
        }
        private void ArrangeFormsBelow()
        {
            if (formClientes != null && !formClientes.IsDisposed)
            {
                ArrangeFormBelow(formClientes);
            }
            if (formFornecedores != null && !formFornecedores.IsDisposed)
            {
                ArrangeFormBelow(formFornecedores);
            }
            if (formEstoque != null && !formEstoque.IsDisposed)
            {
                ArrangeFormBelow(formEstoque);
            }
        }
    }
}