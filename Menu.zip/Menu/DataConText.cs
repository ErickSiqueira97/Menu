﻿
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System.IO;
using System.Reflection.Emit;
using System.Runtime.Remoting.Contexts;

namespace Fiscal
{
    public class ConnectionParams
    {
        public static string ConnectionString(string configSoftMaster)
        {
            string caminhoBancoDados = "C:\\SGBR\\Master\\ConfigSoftMaster.ini";

            if (File.Exists(configSoftMaster))
            {
                string[] linhas = File.ReadAllLines(configSoftMaster);
                foreach (string linha in linhas)
                {
                    if (linha.StartsWith("Conexao="))
                    {
                        caminhoBancoDados = linha.Substring("Conexao=".Length);
                        break;
                    }
                }

                if (string.IsNullOrEmpty(caminhoBancoDados))
                {
                    throw new Exception("Banco de dados não encontrado");
                }
            }
            else
            {
                throw new FileNotFoundException("Arquivo ConfigSoftMaster não encontrado", configSoftMaster);
            }

            return $"DataSource=localhost;Database={caminhoBancoDados};Port=3050;User=SYSDBA;Password=masterkey;Charset=UTF8;Dialect=3;Connection lifetime=15;PacketSize=8192;ServerType=0;Unicode=True;Max Pool Size=1000";
        }
    }
}
