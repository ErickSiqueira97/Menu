﻿using System;
using System.Data.SqlClient;

public class Ado
{
    private string connectionString;

    public Ado(string connectionString)
    {
        this.connectionString = connectionString;
    }

    public void InsertProduto(string PRODUTO, int quantidade, string tipo, double valorFornecedor, double valorFinal, double lucro)
    {
        using (SqlConnection connection = new SqlConnection(connectionString))
        {
            connection.Open();
            string query = "INSERT INTO Produtos (PRODUTO, Quantidade, Tipo, ValorFornecedor, ValorFinal, Lucro) VALUES (@PRODUTO, @Quantidade, @Tipo, @ValorFornecedor, @ValorFinal, @Lucro)";
            using (SqlCommand cmd = new SqlCommand(query, connection))
            {
                cmd.Parameters.AddWithValue("PRODUTO", PRODUTO);
                cmd.Parameters.AddWithValue("@Quantidade", quantidade);
                cmd.Parameters.AddWithValue("@Tipo", tipo);
                cmd.Parameters.AddWithValue("@ValorFornecedor", valorFornecedor);
                cmd.Parameters.AddWithValue("@ValorFinal", valorFinal);
                cmd.Parameters.AddWithValue("@Lucro", lucro);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
